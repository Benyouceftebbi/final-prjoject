import React from 'react';
import { Provider as PaperProvider} from 'react-native-paper';
import {SafeAreaView, StyleSheet, Text} from 'react-native';
import Navigation from './navigation';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import SignInScreen from './screens/SignInScreen/SignInScreen';
import SignUpScreen from './screens/SignUpScreen/SignUpScreen';
import Homepage from './screens/Homepage/Homepage';
import FindOpponentScreen from './screens/FindOpponentScreen/FindOpponentScreen';


export default function App() {
  return (
    <Navigation />
    
  );
}
const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: 'red',
  },
});

