import React from 'react';
import {View, Text} from 'react-native';
import {NavigationContainer} from '@react-navigation/native';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import SignInScreen from '../screens/SignInScreen';
import SignUpScreen from '../screens/SignUpScreen';
import ConfirmEmailScreen from '../screens/ConfirnEmailScreen';
import ForgotPasswordScreen from '../screens/ForgotPasswordScreen';
import NewPasswordScreen from '../screens/NewPasswordScreen';
import Homepage from '../screens/Homepage/Homepage'
import FindOpponent from "../screens/FindOpponentScreen/FindOpponentScreen"
import ProfileScreen from "../screens/ProfileScreen/ProfileScreen"
import SurveyScreen from "../screens/SurveyScreen/SurveyScreen"
import FindOpponentf from "../screens/FindOpponentf/FindOpponentf"
import FindOpponentb from "../screens/FindOpponentb/FindOpponentb"
import FindOpponentt from "../screens/FindOpponentt/FindOpponentt"
import FindTeamScreen from "../screens/FindTeamScreen/FindTeamScreen"
import CreateTeamScreen from "../screens/CreateTeamScreen/CreateTeam"
import Addmatchf from "../screens/FindOpponentf/AddMatchF/Addmatchf"
import Addmatchb from "../screens/FindOpponentb/Addmatchb/Addmatchb"
import Addmatcht from "../screens/FindOpponentt/AddMatcht/Addmatcht"
const {Navigator, Screen} = createNativeStackNavigator();

const Navigation = () => (
  
    <NavigationContainer>
        <Navigator  >
           
          <Screen name="Signin" component={SignInScreen}></Screen>
          <Screen name="Home" component={Homepage}></Screen>
          <Screen name="Don't have an account? Create one" component={SignUpScreen}></Screen>
          <Screen name="Forgot password?" component={ForgotPasswordScreen}></Screen>
          <Screen name="FindOpponent" component={FindOpponent}></Screen>
          <Screen name="ConfirmEmailScreen" component={ConfirmEmailScreen}></Screen>
          <Screen name="Profile" component={ProfileScreen}></Screen>
          <Screen name="Finish" component={SurveyScreen}></Screen>
          <Screen name="Football" component={FindOpponentf}></Screen>
          <Screen name="Basketball" component={FindOpponentb}></Screen>
          <Screen name="Tennis" component={FindOpponentt}></Screen>
          <Screen name="FindTeam" component={FindTeamScreen}></Screen>
          <Screen name="CreateTeam" component={FindTeamScreen}></Screen>
          <Screen name="Addmatchf" component={Addmatchf}></Screen>
          <Screen name="Addmatchb" component={Addmatchb}></Screen>
           <Screen name="Addmatcht" component={Addmatcht}></Screen>

         
         

         
           
          

        
        
        </Navigator>
    
    </NavigationContainer>
  
)
export default Navigation;
