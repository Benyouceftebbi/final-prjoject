import * as React from 'react';
import { Toolbar,ScrollView,Image,View, Button, StyleSheet, TouchableOpacity, Text,IconButton,Colors } from "react-native";
import Icon from 'react-native-vector-icons/FontAwesome';
import { SafeAreaView } from 'react-native';
import Ionicons from 'react-native-vector-icons/Ionicons'

import { FlatList } from 'react-native-gesture-handler';

import { NavigationContainer } from '@react-navigation/native';
import CustomButton from '../../components/CustomButton';
import Logo from '../../assets/images/teamup';

interface Homepageprops {
  navigation: any;
}



const  Homepage = (props : Homepageprops) =>{
  
   const onFindOpponentPressed = () => props.navigation.navigate("FindOpponent");
   const onFindTeamPressed = () => props.navigation.navigate("FindTeam")
   const onCreateTeamPressed = () => props.navigation.navigate("CreateTeam")
    return (
      <View style = {styles.container}>  
        
          <View style = {styles.headerWrapper}>
               <TouchableOpacity onPress={() => props.navigation.navigate('Profile')} >  
                <Icon style={{paddingLeft:20}} name="user-circle" size={30} color="#009" />
               </TouchableOpacity>
              <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
                 
                 <Image source={Logo}style={[styles.logo, {height:100}]} resizeMode="contain"/>
              </View>
              <TouchableOpacity>
                <Icon style={{paddingRight:20}} name="align-right" size={25} color="#009" />
              </TouchableOpacity>
          </View>
        
        <ScrollView style={{flex:1}}>
            <Text style={{fontSize:20,fontWeight:'bold',textAlign:'center'}}>WELCOME!</Text>
              <CustomButton text="Find an Opponent ⚔️" onPress={onFindOpponentPressed} />
              <CustomButton text="Find a team ⛹️" onPress={onFindTeamPressed} />
              <CustomButton text="Create a team ⛹️" onPress={onCreateTeamPressed} />
            

          </ScrollView>
      </View>
      
    )
  }


  const styles = StyleSheet.create({
      container: {
        flex:1,
        backgroundColor:'white'
      },
      headerWrapper:{
        flexDirection: 'row',
        justifyContent: 'space-between',
        paddingVertical:50,
        alignItems:"center",
      },
      ibutton:{
        backgroundColor:'grey',
      },
       logo: {
    width: '70%',
    maxWidth: 300,
    maxHeight: 200,
  },
  });
  export default Homepage;