import * as React from 'react';
import { Toolbar,ScrollView,Image,View, Button, StyleSheet, TouchableOpacity, Text,IconButton,Colors } from "react-native";
import Icon from 'react-native-vector-icons/FontAwesome';
import { SafeAreaView } from 'react-native';
import Ionicons from 'react-native-vector-icons/Ionicons'
import { FlatList } from 'react-native-gesture-handler';
import { NavigationContainer } from '@react-navigation/native';

interface HomepageProps {
  navigation: any;
}

export function Homepage(HomepageProps) {
    return (
      <View style = {styles.container}>  
        <SafeAreaView style={{}}>
          <View style = {styles.headerWrapper}>
              <TouchableOpacity onPress={() => navigation.navigate('Profile')}>
                <Icon style={{paddingLeft:20}} name="user-circle" size={30} color="#009" />
              </TouchableOpacity>
              <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
                  <Text style={{fontSize:20,left:80,fontWeight:'bold'}}>TeamUP!</Text>
                  <Text style={{fontSize:20,right:185,fontWeight:'normal',position:"absolute"}}>Osman</Text>
              </View>
              <TouchableOpacity>
                <Icon style={{paddingRight:20}} name="align-right" size={25} color="#009" />
              </TouchableOpacity>
          </View>
        </SafeAreaView>
        <ScrollView style={{flex:1}}>
            <Text style={{fontSize:20,fontWeight:'bold',textAlign:'center'}}>Which Sport Do You Interest?</Text>
            <TouchableOpacity sty >
              <Image style={{width:300,height:200,borderRadius:50,left:32}} source={require('../../assets/images/teamup')} />
            </TouchableOpacity>
                  <Text style={{fontWeight:'bold',fontSize:30,color:'white',top:145,left:50,position:'absolute'}}>Football</Text>
            <TouchableOpacity>
              <Image style={{width:300,height:200,borderRadius:50,left:32,top:5}} source={require('../../assets/images/teamup')} />
            </TouchableOpacity>
                  <Text style={{fontWeight:'bold',fontSize:30,color:'white',top:350,left:50,position:'absolute'}}>Basketball</Text>
            <TouchableOpacity>
            <Image style={{width:300,height:200,borderRadius:50,left:32,top:10}} source={require('../../assets/images/teamup')} />
            </TouchableOpacity>
                  <Text style={{fontWeight:'bold',fontSize:30,color:'white',top:550,left:50,position:'absolute'}}>Tennis</Text>
            <Image style={{width:300,height:200,borderRadius:50,left:32,top:350}} source={require('../../assets/images/teamup')} />
          </ScrollView>
      </View>
      
    )
  }
//<Ionicons style = {styles.profileIcon} name='person-circle-outline' size={40} />

  const styles = StyleSheet.create({
      container: {
        flex:1,
        backgroundColor:'white'
      },
      headerWrapper:{
        flexDirection: 'row',
        justifyContent: 'space-between',
        paddingVertical:50,
        alignItems:"center",
      },
      ibutton:{
        backgroundColor:'white',
      }
  });