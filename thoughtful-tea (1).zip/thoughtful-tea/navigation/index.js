import React from 'react';
import {View, Text} from 'react-native';
import {NavigationContainer} from '@react-navigation/native';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import SignInScreen from '../screens/SignInScreen';
import SignUpScreen from '../screens/SignUpScreen';
import ConfirmEmailScreen from '../screens/ConfirnEmailScreen';
import ForgotPasswordScreen from '../screens/ForgotPasswordScreen';
import NewPasswordScreen from '../screens/NewPasswordScreen';
import Homepage from '../screens/Homepage/Homepage'
import FindOpponent from "../screens/FindOpponentScreen/FindOpponentScreen"

const {Navigator, Screen} = createNativeStackNavigator();

const Navigation = () => (
  
    <NavigationContainer>
        <Navigator  screenOptions={{headerShown: false}}>
          
          <Screen name="Signin" component={SignInScreen}></Screen>
          <Screen name="Home" component={Homepage}></Screen>
          <Screen name="Don't have an account? Create one" component={SignUpScreen}></Screen>
          <Screen name="Forgot password?" component={ForgotPasswordScreen}></Screen>
          <Screen name="FindOpponent" component={FindOpponent}></Screen>
          <Screen name="ConfirmEmailScreen" component={ConfirmEmailScreen}></Screen>
         

         
           
          

        
        
        </Navigator>
    
    </NavigationContainer>
  
)
export default Navigation;
